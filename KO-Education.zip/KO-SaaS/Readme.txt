~~~~~~~Titre~~~~~~~
KO-Education

~~~~~~~Team~~~~~~~
LAHSSINI Omar
ELMANSOURI Khaoula

~~~~~~~Technologie de projet~~~~~~~
*HTML5
*CSS3
*JAVASCRIPT
*JQUERY
*SAAS
*BOOTSTRAP 
*Visual Studio Code
*Visual Studio 2019
*Sublime Text 3

~~~~~~~Structure du dossier de projet~~~~~~~ 
KO-SaaS > assests - forms - debug - index - portfolio-details - Readme.

~~~~~~~Description~~~~~~~
KO-Education is a webSite for the parents to make sure that thier children are having a healthy mentality, and training them to be good parents.
By offering so many services for the kids and thier parents.

~~~~~~~The Template~~~~~~~
Template Name: Bethany
Template URL: https://bootstrapmade.com/bethany-free-onepage-bootstrap-theme/
Author: BootstrapMade.com
License: https://bootstrapmade.com/license/

~~~~~~~Ressource~~~~~~~
https://unsplash.com/
https://leapsnboundsacademy.com/
https://fr.freepik.com/
https://ifstudies.org/
https://fr.wix.com/logo/creer-logo
